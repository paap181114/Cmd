scp squares/$1 root@hetzner04:/var/www/pelisalacarta.mimediacenter.info/squares/
scp posters/$1 root@hetzner04:/var/www/pelisalacarta.mimediacenter.info/posters/
scp banners/$1 root@hetzner04:/var/www/pelisalacarta.mimediacenter.info/banners/

